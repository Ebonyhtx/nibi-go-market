// 最小 MCP stdio 服务器：initialize / tools/list / tools/call（line-delimited JSON）。
import { createInterface } from "node:readline";

const serverName = "market_hello";
const serverVersion = "0.1.1";

function send(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`);
}

function text(id, value) {
  send({ jsonrpc: "2.0", id, result: { content: [{ type: "text", text: value }] } });
}

const input = createInterface({ input: process.stdin });
input.on("line", (line) => {
  let message;
  try {
    message = JSON.parse(line);
  } catch {
    return;
  }
  const { id, method, params } = message ?? {};
  if (method === "initialize") {
    send({
      jsonrpc: "2.0",
      id,
      result: {
        protocolVersion: params?.protocolVersion ?? "2025-06-18",
        capabilities: { tools: {} },
        serverInfo: { name: serverName, version: serverVersion },
      },
    });
    return;
  }
  if (method === "tools/list") {
    send({
      jsonrpc: "2.0",
      id,
      result: {
        tools: [
          {
            name: "hello",
            description: "返回一句问候；可选 name 参数。",
            inputSchema: {
              type: "object",
              properties: { name: { type: "string", description: "称呼" } },
              additionalProperties: false,
            },
          },
        ],
      },
    });
    return;
  }
  if (method === "tools/call") {
    const name = typeof params?.arguments?.name === "string" ? params.arguments.name : "NIBI";
    text(id, `你好，${name}！这是来自市场插件 ${serverName} v${serverVersion} 的问候。`);
    return;
  }
  if (method === "notifications/initialized" || method === "notifications/cancelled") return;
  if (id !== undefined) {
    send({ jsonrpc: "2.0", id, error: { code: -32601, message: `Method not found: ${method}` } });
  }
});
